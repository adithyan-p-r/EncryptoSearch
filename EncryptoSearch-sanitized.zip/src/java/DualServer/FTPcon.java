package DualServer;

import java.io.File;
import java.io.FileInputStream;
import org.apache.commons.net.ftp.FTPClient;

public class FTPcon {
    FTPClient client = new FTPClient();
    FileInputStream fis = null;
    boolean status;

    public boolean upload(File file) {
        try {
            String username = System.getenv("ENCRYPTOSEARCH_FTP_USER");
            String password = System.getenv("ENCRYPTOSEARCH_FTP_PASSWORD");
            String host = System.getenv("ENCRYPTOSEARCH_FTP_HOST");
            if (host == null || username == null || password == null) {
                throw new IllegalStateException("FTP settings are missing from the environment.");
            }
            client.connect(host);
            if (!client.login(username, password)) {
                throw new IllegalStateException("FTP login failed.");
            }
            client.enterLocalPassiveMode();
            fis = new FileInputStream(file);
            status = client.storeFile("/" + file.getName(), fis);
            client.logout();
            fis.close();
        } catch (Exception e) {
            status = false;
        }
        return status;
    }
}

