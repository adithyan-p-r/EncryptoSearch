/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DualServer;

/**
 * Fixed KEYGEN class with proper Base64 encoding/decoding
 * @author Murthi (Updated for compatibility)
 */
import java.security.spec.KeySpec;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import java.util.Base64;  // Use Java 8+ built-in Base64

public class KEYGEN {

    private static final String UNICODE_FORMAT = "UTF8";
    public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
    private KeySpec ks;
    private SecretKeyFactory skf;
    private Cipher cipher;
    byte[] arrayBytes;
    private String myEncryptionKey;
    private String myEncryptionScheme;
    SecretKey key;

    public KEYGEN() throws Exception {
        myEncryptionKey = "C12EFGBHIJ34KDLMN89AOPQR";
        myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
        arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
        ks = new DESedeKeySpec(arrayBytes);
        skf = SecretKeyFactory.getInstance(myEncryptionScheme);
        cipher = Cipher.getInstance(myEncryptionScheme);
        key = skf.generateSecret(ks);
    }

    public String encrypt(String unencryptedString) {
        String encryptedString = null;
        try {
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);
            byte[] encryptedText = cipher.doFinal(plainText);
            
            // FIX 1: Use Java's built-in Base64 encoder
            encryptedString = Base64.getEncoder().encodeToString(encryptedText);
            
        } catch (Exception e) {
            System.err.println("Encryption error: " + e.getMessage());
            e.printStackTrace();
        }
        return encryptedString;
    }

    public String decrypt(String encryptedString) {
        String decryptedText = null;
        try {
            cipher.init(Cipher.DECRYPT_MODE, key);
            
            // FIX 2: Use Java's built-in Base64 decoder directly on the string
            byte[] encryptedText = Base64.getDecoder().decode(encryptedString);
            
            byte[] plainText = cipher.doFinal(encryptedText);
            decryptedText = new String(plainText);
            
        } catch (Exception e) {
            System.err.println("Decryption error: " + e.getMessage());
            e.printStackTrace();
        }
        return decryptedText;
    }

    String encrypt(SecretKey secretKey) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
