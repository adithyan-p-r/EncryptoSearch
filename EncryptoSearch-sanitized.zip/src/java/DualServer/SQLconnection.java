package DualServer;

import java.sql.Connection;
import java.sql.DriverManager;

public class SQLconnection {
    static Connection con;

    public static Connection getconnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = System.getenv("ENCRYPTOSEARCH_DB_URL");
            String user = System.getenv("ENCRYPTOSEARCH_DB_USER");
            String password = System.getenv("ENCRYPTOSEARCH_DB_PASSWORD");
            if (url == null || user == null || password == null) {
                throw new IllegalStateException("Database settings are missing from the environment.");
            }
            con = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            con = null;
        }
        return con;
    }
}

