Sanitized configuration
=======================

Sensitive database and FTP credentials have been removed from the source.
Set these environment variables before running the application:

  ENCRYPTOSEARCH_DB_URL
  ENCRYPTOSEARCH_DB_USER
  ENCRYPTOSEARCH_DB_PASSWORD
  ENCRYPTOSEARCH_FTP_HOST
  ENCRYPTOSEARCH_FTP_USER
  ENCRYPTOSEARCH_FTP_PASSWORD

The database URL should include the database name and any required connection
options. Existing third-party license and attribution notices are retained.
The original login note and generated build folders were excluded because they
contained demo credentials or duplicate generated files.
